//src/utills/DataLoadingValidator.js

import React, { useEffect, useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { Alert, Box, Card, CardContent, CircularProgress, Typography, Stack, Paper } from '@mui/material';
import { Line } from 'recharts';
import { fetchSpatialData } from '../slices/spatialSlice';
import { ProgressIndicator } from '../components/analysis/spatial-analysis/ProgressIndicator';
import { backgroundMonitor } from '../utils/backgroundMonitor';

// Status checker component
const StatusCheck = ({ label, status, details }) => (
  <Alert 
    severity={status === 'success' ? 'success' : status === 'error' ? 'error' : 'info'}
    sx={{ mb: 1 }}
  >
    <Typography variant="subtitle2">{label}</Typography>
    {details && (
      <Typography variant="caption" display="block">
        {details}
      </Typography>
    )}
  </Alert>
);

const DataLoadingValidator = ({ selectedCommodity = 'beans_kidney_red' }) => {
  const [validationState, setValidationState] = useState({
    loading: true,
    currentStage: 'initializing',
    stages: {
      geometries: { status: 'pending' },
      precomputed: { status: 'pending' },
      unified: { status: 'pending' },
      merged: { status: 'pending' }
    },
    errors: [],
    stats: {
      totalFeatures: 0,
      timeSeriesPoints: 0,
      marketClusters: 0,
      flowConnections: 0
    }
  });

  const dispatch = useDispatch();
  const spatialData = useSelector(state => state.spatial.data);
  const geometries = useSelector(state => state.geometries.data);

  useEffect(() => {
    const validateData = async () => {
      const metric = backgroundMonitor.startMetric('data-validation');
      
      try {
        setValidationState(prev => ({
          ...prev,
          loading: true,
          currentStage: 'loading-geometries'
        }));

        // 1. Validate Geometries
        if (!geometries) {
          await dispatch(fetchSpatialData({ selectedCommodity }));
        }
        
        setValidationState(prev => ({
          ...prev,
          stages: {
            ...prev.stages,
            geometries: {
              status: 'success',
              count: geometries ? Object.keys(geometries).length : 0
            }
          }
        }));

        // 2. Validate Precomputed Data
        if (spatialData) {
          const { timeSeriesData, marketClusters, flowMaps } = spatialData;
          
          setValidationState(prev => ({
            ...prev,
            stages: {
              ...prev.stages,
              precomputed: {
                status: 'success',
                timeSeriesCount: timeSeriesData?.length || 0,
                clusterCount: marketClusters?.length || 0,
                flowCount: flowMaps?.length || 0
              }
            },
            stats: {
              timeSeriesPoints: timeSeriesData?.length || 0,
              marketClusters: marketClusters?.length || 0,
              flowConnections: flowMaps?.length || 0
            }
          }));
        }

        // 3. Validate Spatial Correlation
        if (spatialData?.spatialAutocorrelation) {
          const { moran_i, significance } = spatialData.spatialAutocorrelation;
          setValidationState(prev => ({
            ...prev,
            stages: {
              ...prev.stages,
              spatial: {
                status: 'success',
                moran_i,
                significance
              }
            }
          }));
        }

        setValidationState(prev => ({
          ...prev,
          loading: false,
          currentStage: 'complete'
        }));

        metric.finish({ status: 'success' });

      } catch (error) {
        console.error('Data validation error:', error);
        setValidationState(prev => ({
          ...prev,
          loading: false,
          currentStage: 'error',
          errors: [...prev.errors, error.message]
        }));
        metric.finish({ status: 'error', error: error.message });
      }
    };

    validateData();
  }, [dispatch, selectedCommodity, geometries, spatialData]);

  if (validationState.loading) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" minHeight={400}>
        <Stack spacing={2} alignItems="center">
          <CircularProgress />
          <Typography variant="subtitle1" color="textSecondary">
            {validationState.currentStage}
          </Typography>
        </Stack>
      </Box>
    );
  }

  if (validationState.errors.length > 0) {
    return (
      <Alert severity="error" sx={{ mb: 2 }}>
        <AlertTitle>Data Validation Errors</AlertTitle>
        {validationState.errors.map((error, index) => (
          <Typography key={index} variant="body2">{error}</Typography>
        ))}
      </Alert>
    );
  }

  return (
    <Box>
      <Typography variant="h6" gutterBottom>
        Data Loading Validation
      </Typography>

      <Stack spacing={2}>
        {/* Geometry Data */}
        <Paper sx={{ p: 2 }}>
          <Typography variant="subtitle1" gutterBottom>
            Geometry Data Status
          </Typography>
          <StatusCheck 
            label="Geometry Features"
            status={validationState.stages.geometries.status}
            details={`Found ${validationState.stages.geometries.count || 0} regions`}
          />
        </Paper>

        {/* Precomputed Data */}
        <Paper sx={{ p: 2 }}>
          <Typography variant="subtitle1" gutterBottom>
            Precomputed Data Status
          </Typography>
          <Stack spacing={1}>
            <StatusCheck 
              label="Time Series Data"
              status={validationState.stages.precomputed.status}
              details={`${validationState.stats.timeSeriesPoints} data points`}
            />
            <StatusCheck 
              label="Market Clusters"
              status={validationState.stages.precomputed.status}
              details={`${validationState.stats.marketClusters} clusters identified`}
            />
            <StatusCheck 
              label="Flow Connections"
              status={validationState.stages.precomputed.status}
              details={`${validationState.stats.flowConnections} market flows`}
            />
          </Stack>
        </Paper>

        {/* Spatial Analysis */}
        {validationState.stages.spatial && (
          <Paper sx={{ p: 2 }}>
            <Typography variant="subtitle1" gutterBottom>
              Spatial Analysis Status
            </Typography>
            <StatusCheck 
              label="Spatial Autocorrelation"
              status={validationState.stages.spatial.status}
              details={`Moran's I: ${validationState.stages.spatial.moran_i?.toFixed(3)}`}
            />
          </Paper>
        )}
      </Stack>

      {/* Data Summary */}
      <Card sx={{ mt: 2 }}>
        <CardContent>
          <Typography variant="h6" gutterBottom>
            Data Summary
          </Typography>
          <Typography variant="body2">
            • Time Series Coverage: {validationState.stats.timeSeriesPoints} points
          </Typography>
          <Typography variant="body2">
            • Market Clusters: {validationState.stats.marketClusters}
          </Typography>
          <Typography variant="body2">
            • Flow Connections: {validationState.stats.flowConnections}
          </Typography>
          {validationState.stages.spatial && (
            <Typography variant="body2">
              • Spatial Correlation (Moran's I): {validationState.stages.spatial.moran_i?.toFixed(3)}
            </Typography>
          )}
        </CardContent>
      </Card>
    </Box>
  );
};

export default DataLoadingValidator;