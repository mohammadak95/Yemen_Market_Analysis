// src/utils/PrecomputedDataManager.js

import { backgroundMonitor } from './backgroundMonitor';
import { dataLoadingMonitor } from './dataMonitoring';
import { getDataPath } from './dataUtils';
import { spatialDataMerger } from './spatialDataMerger';
export {loadGeometries} from './spatialDataMerger';

/**
 * @typedef {import('../types/spatialTypes').PrecomputedData} PrecomputedData
 * @typedef {import('../types/spatialTypes').SpatialAutocorrelation} SpatialAutocorrelation
 */

/**
 * Fetches JSON data with retry mechanism.
 */
async function fetchWithRetry(url, options = {}, retries = 3, backoff = 300) {
  for (let i = 0; i < retries; i++) {
    try {
      const response = await fetch(url, options);
      if (!response.ok) {
        throw new Error(`Fetch error: ${response.statusText}`);
      }
      return await response.json();
    } catch (error) {
      if (i < retries - 1) {
        await new Promise(resolve => setTimeout(resolve, backoff * (i + 1)));
      } else {
        throw error;
      }
    }
  }
}

export class PrecomputedDataManager {
  constructor() {
    this.cache = new Map();
    this.pendingRequests = new Map();
    this._isInitialized = false;
    this.cacheTimeout = 30 * 60 * 1000; // 30 minutes
    this._cacheInitialized = false;
  }

  async initialize() {
    if (this._isInitialized) return;
    try {
      backgroundMonitor.init();
      this._isInitialized = true;
      this._cacheInitialized = true;
      console.log('PrecomputedDataManager initialized');
    } catch (error) {
      console.error('Failed to initialize PrecomputedDataManager:', error);
      this._cacheInitialized = false;
      throw error;
    }
  }

  isCacheInitialized() {
    return this._cacheInitialized;
  }

  isInitialized() {
    return this._isInitialized;
  }

  async processSpatialData(selectedCommodity, selectedDate, options = {}) {
    if (!this._isInitialized) {
      await this.initialize();
    }

    const metric = backgroundMonitor.startMetric('process-spatial-data');
    const sanitizedCommodity = this.sanitizeCommodityName(selectedCommodity);
    const cacheKey = `spatial_${sanitizedCommodity}_${selectedDate}`;

    try {
      const cachedData = this.getCachedData(cacheKey);
      if (cachedData) {
        metric.finish({ status: 'success', source: 'cache' });
        return cachedData;
      }

      if (this.pendingRequests.has(cacheKey)) {
        return this.pendingRequests.get(cacheKey);
      }

      const filePath = getDataPath(`preprocessed_by_commodity/preprocessed_yemen_market_data_${sanitizedCommodity}.json`);
      
      console.log('Loading preprocessed data:', {
        originalCommodity: selectedCommodity,
        sanitizedCommodity,
        filePath
      });

      let response;
      for (let i = 0; i < 3; i++) {
        response = await fetch(filePath);
        if (response.ok) break;
        await new Promise(resolve => setTimeout(resolve, 1000 * (i + 1)));
      }

      if (!response.ok) {
        throw new Error(`Failed to fetch data: ${response.status} ${response.statusText}`);
      }

      const data = await response.json();
      
      if (!data.time_series_data || !data.market_clusters || !data.market_shocks) {
        throw new Error('Invalid data structure: missing required fields');
      }

      const transformedData = this.transformPreprocessedData(data, selectedDate);

      if (options.geometries) {
        transformedData.geoData.features = transformedData.geoData.features.map(feature => {
          const regionId = this.normalizeRegionId(feature.properties.id);
          const geometryData = options.geometries[regionId];
          
          if (geometryData) {
            return {
              ...feature,
              geometry: geometryData.geometry,
              properties: {
                ...feature.properties,
                ...geometryData.properties
              }
            };
          }
          console.warn(`No geometry found for region: ${regionId}`);
          return feature;
        });
      }

      this.setCachedData(cacheKey, transformedData);
      metric.finish({ status: 'success' });
      return transformedData;

    } catch (error) {
      console.error('Error processing spatial data:', error);
      metric.finish({ status: 'error', error: error.message });
      throw error;
    } finally {
      this.pendingRequests.delete(cacheKey);
    }
  }

  sanitizeCommodityName(commodity) {
    return commodity.toLowerCase()
      .replace(/[(),\s]+/g, '_')
      .replace(/_+$/, '');
  }


  async loadAndProcessData(commodity, date, options) {
    const metric = dataLoadingMonitor.startRequest('load-precomputed-data');

    try {
      const sanitizedCommodity = this.sanitizeCommodityName(commodity);
      const filePath = getDataPath(`preprocessed_by_commodity/preprocessed_yemen_market_data_${sanitizedCommodity}.json`);

      const data = await fetchWithRetry(filePath);
      const transformedData = this.transformPreprocessedData(data, date);

      let geometries;
      if (options.geometries) {
        geometries = new Map(Object.entries(options.geometries));
      } else {
        geometries = await spatialDataMerger.loadGeometries();
      }

      transformedData.geoData.features = transformedData.geoData.features.map((feature) => {
        const regionId = this.normalizeRegionId(feature.properties.id);
        const geometryData = geometries.get(regionId);
        if (geometryData) {
          return {
            ...feature,
            geometry: geometryData.geometry,
          };
        }
        return feature;
      });

      dataLoadingMonitor.completeRequest(metric.id, transformedData);
      return transformedData;
    } catch (error) {
      dataLoadingMonitor.logError(metric.id, error);
      throw error;
    }
  }

  transformPreprocessedData(data, targetDate) {
    const timeSeriesData = data.time_series_data || [];
    const uniqueMonths = [...new Set(timeSeriesData.map(d => d.month))].sort();
    const selectedDate = targetDate || uniqueMonths[uniqueMonths.length - 1];

    return {
      geoData: this.extractGeoData(data, selectedDate),
      marketClusters: data.market_clusters || [],
      detectedShocks: this.filterShocksByDate(data.market_shocks, selectedDate),
      timeSeriesData: timeSeriesData,
      flowMaps: this.transformFlowData(data.flow_analysis),
      analysisMetrics: data.analysis_metrics || {},
      spatialAutocorrelation: data.spatial_autocorrelation || {},
      metadata: data.metadata || {},
      uniqueMonths
    };
  }

  extractGeoData(data, targetDate) {
    const timeSeriesForDate = data.time_series_data?.find(d => 
      d.month === targetDate
    ) || null;

    const features = data.market_clusters?.reduce((acc, cluster) => {
      // Add main market
      acc.push({
        type: 'Feature',
        properties: {
          id: cluster.main_market,
          isMainMarket: true,
          clusterSize: cluster.market_count,
          marketRole: 'hub',
          priceData: timeSeriesForDate,
          cluster_id: cluster.cluster_id
        },
        geometry: null
      });

      // Add connected markets
      cluster.connected_markets.forEach(market => {
        acc.push({
          type: 'Feature',
          properties: {
            id: market,
            isMainMarket: false,
            clusterSize: cluster.market_count,
            marketRole: 'peripheral',
            priceData: timeSeriesForDate,
            cluster_id: cluster.cluster_id
          },
          geometry: null
        });
      });

      return acc;
    }, []);

    return {
      type: 'FeatureCollection',
      features: features || []
    };
  }

  filterShocksByDate(shocks = [], targetDate) {
    if (!targetDate) return [];
    return shocks.filter(shock => shock.date.startsWith(targetDate));
  }

  transformFlowData(flows = []) {
    return flows.map(flow => ({
      source: flow.source,
      target: flow.target,
      flow_weight: flow.total_flow,
      avg_flow: flow.avg_flow,
      flow_count: flow.flow_count,
      price_differential: flow.avg_price_differential
    }));
  }

  getCachedData(key) {
    const cached = this.cache.get(key);
    if (!cached) return null;

    if (Date.now() - cached.timestamp > this.cacheTimeout) {
      this.cache.delete(key);
      return null;
    }

    return cached.data;
  }

  setCachedData(key, data) {
    this.cache.set(key, {
      data,
      timestamp: Date.now()
    });
  }

  clearCache() {
    this.cache.clear();
    this.pendingRequests.clear();
    this._cacheInitialized = false;
  }

  destroy() {
    this.clearCache();
    this._isInitialized = false;
    this._cacheInitialized = false;
  }

  normalizeRegionId(id) {
    if (!id) return null;
    
    const specialCases = {
      'san_a': 'sanaa',
      'san_a__governorate': 'sanaa',
      'sanaa': 'sanaa',
      'sana_a': 'sanaa',
      'lahij': 'lahj',
      'lahij_governorate': 'lahj',
      '_adan_governorate': 'aden',
      'ta_izz_governorate': 'taizz',
      'al_hudaydah_governorate': 'al_hudaydah',
      'al_jawf_governorate': 'al_jawf',
      'shabwah_governorate': 'shabwah',
      'hadhramaut': 'hadramaut'
    };

    const normalized = id
      .toLowerCase()
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/[^a-z0-9]/g, '_')
      .replace(/_+/g, '_')
      .replace(/^_|_$/g, '');

    return specialCases[normalized] || normalized;
  }

  async loadGeometries() {
    const cacheKey = 'geometries';
    if (this.cache.has(cacheKey)) {
      return this.cache.get(cacheKey);
    }

    try {
      const [boundaries, enhanced] = await Promise.all([
        fetch(getDataPath('choropleth_data/geoBoundaries-YEM-ADM1.geojson'))
          .then(res => res.json()),
        fetch(getDataPath('enhanced_unified_data_with_residual.geojson'))
          .then(res => res.json())
      ]);

      if (!boundaries?.features || !enhanced?.features) {
        throw new Error('Invalid geometry data structure');
      }

      const geometryMap = new Map();

      boundaries.features.forEach(feature => {
        const id = this.normalizeRegionId(
          feature.properties.shapeName || 
          feature.properties.admin1
        );
        
        if (id) {
          geometryMap.set(id, {
            geometry: feature.geometry,
            properties: { ...feature.properties }
          });
        }
      });

      enhanced.features.forEach(feature => {
        const id = this.normalizeRegionId(
          feature.properties.region_id ||
          feature.properties.admin1
        );
        
        if (id && geometryMap.has(id)) {
          const existing = geometryMap.get(id);
          geometryMap.set(id, {
            geometry: existing.geometry,
            properties: {
              ...existing.properties,
              ...feature.properties
            }
          });
        }
      });

      this.cache.set(cacheKey, geometryMap);
      return geometryMap;

    } catch (error) {
      console.error('Error loading geometries:', error);
      throw error;
    }
  }
}

export const precomputedDataManager = new PrecomputedDataManager();