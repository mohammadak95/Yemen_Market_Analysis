// src/types/spatialTypes.js

/**
 * @typedef {Object} PrecomputedData
 * @property {TimeSeriesEntry[]} timeSeriesData
 * @property {MarketShock[]} marketShocks
 * @property {MarketCluster[]} marketClusters
 * @property {FlowAnalysis[]} flowAnalysis
 * @property {SpatialAutocorrelation} spatialAutocorrelation
 * @property {DataMetadata} metadata
 */

/**
 * @typedef {Object} TimeSeriesEntry
 * @property {string} month
 * @property {number} avgUsdPrice
 * @property {number} volatility
 * @property {number} sampleSize
 */

/**
 * @typedef {Object} MarketShock
 * @property {string} region
 * @property {string} date
 * @property {number} magnitude
 * @property {'price_surge' | 'price_drop'} type
 * @property {'high' | 'medium' | 'low'} severity
 * @property {number} price_change
 * @property {number} previous_price
 * @property {number} current_price
 */

/**
 * @typedef {Object} MarketCluster
 * @property {number} cluster_id
 * @property {string} main_market
 * @property {string[]} connected_markets
 * @property {number} market_count
 * @property {Object} metrics
 * @property {number} metrics.totalFlow
 * @property {number} metrics.avgFlow
 * @property {number} metrics.flowDensity
 */

/**
 * @typedef {Object} FlowAnalysis
 * @property {string} source
 * @property {string} target
 * @property {number} total_flow
 * @property {number} avg_flow
 * @property {number} flow_count
 * @property {number} avg_price_differential
 */

/**
 * @typedef {Object} SpatialAutocorrelation
 * @property {number} moran_i
 * @property {number} p_value
 * @property {boolean} significance
 */

/**
 * @typedef {Object} DataMetadata
 * @property {string} commodity
 * @property {string} data_source
 * @property {string} processed_date
 * @property {number} total_clusters
 */

/**
 * @typedef {Object} SpatialViewConfig
 * @property {[number, number]} center
 * @property {number} zoom
 */

/**
 * @typedef {Object} AnalysisMetrics
 * @property {number} marketCoverage
 * @property {number} integrationLevel
 * @property {number} stability
 * @property {number} observations
 */
